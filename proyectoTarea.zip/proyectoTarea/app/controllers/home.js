'use-strict';

var express = require('express'),
  router = express.Router(),
  mongoose = require('mongoose'),
  loingUser=mongoose.model('login-schema'),
  Article = mongoose.model('Article');

module.exports = function (app) {
  app.use('/', router);
};
router.get('/',(req,res,next)=>{// con esto se redirecciona desde  la rua base
  res.redirect('/loing');// a loing
});

router.get('/loing', function (req, res, next) {//aqui /loing es la ruta
  Article.find(function (err, articles) {
    if (err) return next(err);
    res.render('loing', {//loing aqui es nombre de la platilla
      title: 'Generator-Express MVC',
      articles: articles
    });
  });
});


/*
----------
loing
----------
*/
router.get('/loing',function (req,res,next) {
  res.render('loing',{
    title:'Lonig'
  });

});
router.post('/loing', (req,res,next)=>{
  const user =new loingUser({
    username:req.body.username,
    password:req.body.password,
    email:req.body.email
  });
  user.save();
  res.send("hola que hace");
});
