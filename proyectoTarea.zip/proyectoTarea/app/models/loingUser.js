var mongoose=require('mongoose'),
  Schema = mongoose.Schema;
  var loingSchema = new Schema ({
    username:String,
    password:String,
    email:{type:String, lowercase:true , unique:true}
  },{
    collection:'loguser'
  });
  loingSchema.virtual('date')
    .get(function(){return this._id.getTimestamp();
    });
mongoose.model('login-schema',loingSchema);
